<?php
require_once('../config.php');

function buscarCampus($connect, $pdo)
{
    $q = mysqli_query($connect, "SELECT camId 'ID', camCampus 'Campus', camSigla 'Sigla' from tb_campus");
    
    if (mysqli_num_rows($q) > 0) {
        while ($row = mysqli_fetch_array($q)) {
            echo "<tr><td>" . $row['ID'] . "</td>
                <td>" . $row['Campus'] . "</td>
                <td>" . $row['Sigla'] . "</td>
                <td align='center'><a href='../src/campus.php?funcao=1&id=". $row['ID']."'><i class='fas fa-edit'></i></a></td>                
                <td align='center'><a href='../back/campus_back.php?tipo=deletar&id=". $row['ID']."'><i class='fas fa-trash-alt'></i></a></td></tr>";
                //<td align='center'><a href='#' onclick='javascript: if (confirm('Você realmente deseja excluir esta mensagem?'))location.href='../back/users_back.php?tipo=deletar&id=". $row['ID']."''
        }
    }
}

function voltarCampus($pdo, $id)
{
    $select = "select camCampus 'campus', camSigla 'sigla'  from tb_campus where camId=:id";

    $stmt = $pdo->prepare($select);

    $stmt->bindValue(":id", $id);

    $stmt->execute();
    
    if ($stmt->rowcount() == 1) {
        return $row =$stmt->fetch();
    }
}
?>